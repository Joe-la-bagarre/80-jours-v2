NOTE
===

```html
<!-- Canonical URL -->
  <link rel = "canonical" href = "https://www.exemple.com/">
```